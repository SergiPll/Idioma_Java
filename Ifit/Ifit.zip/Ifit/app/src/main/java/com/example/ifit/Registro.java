package com.example.ifit;

import android.os.Bundle;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.ifit.user.usuario;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registro extends AppCompatActivity {

    //Crear los diferentes objetos donde se guardaran los parámetros para la base de datos y cosas varias
    private String Email, Contrasenya, ConfirmContrasenya, Nombre, puntoFin = "0/0", puntoPartida = "0/0";
    private float distancia = 0;
    private int nivel = 1, puntuacion = 0, valor1 = 0, valor2 = 0;
    private EditText txtemail, txtnombre, txtContrasenya, txtConfirmContrasenya;
    private ImageView flecha;
    private Button registro, bttnMostrar1, bttnMostrar2;
    private boolean errorName = false, errorPass = false, errorEmail = false;
    private DatabaseReference miBd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        //Asignar al objeto Flecha a partir de la imagen del Layout
        flecha = findViewById(R.id.flecha);

        //Generar los objetos de EditText de los que sacaremos los parámetros que ponga el usuario.
        txtnombre = findViewById(R.id.txtNombre);
        txtemail = findViewById(R.id.txtCorreo);
        txtContrasenya = findViewById(R.id.txtContrasenya);
        txtConfirmContrasenya = findViewById(R.id.txtConfirmContrasenya);

        //Asignar que las contraseñas en un principio esten escondidas
        txtContrasenya.setTransformationMethod(new PasswordTransformationMethod());
        txtConfirmContrasenya.setTransformationMethod(new PasswordTransformationMethod());

        //Generar el boton de registro usando como referencia el del Layout
        registro = findViewById(R.id.bttnRegistro);

        bttnMostrar1 = findViewById(R.id.bttnMostrar1);
        bttnMostrar2 = findViewById(R.id.bttnMostrar2);

        // Al clicar en la imagen de la flecha, se redirigirá a la ventana MainActivity
        flecha.setOnClickListener(v -> {
            onBackPressed();
        });

        //Al clicar en el ojo, la contraseña cambiara entre mostrarse o esconderse
        bttnMostrar1.setOnClickListener(v -> {
            if(valor1 == 1){
                txtContrasenya.setTransformationMethod(new PasswordTransformationMethod());
                valor1 = 0;
            } else{
                txtContrasenya.setTransformationMethod(null);
                valor1 = 1;
            }
        });
        //Al clicar en el ojo, la contraseña cambiara entre mostrarse o esconderse
        bttnMostrar2.setOnClickListener(v -> {
            if(valor2 == 1){
                txtConfirmContrasenya.setTransformationMethod(new PasswordTransformationMethod());
                valor2 = 0;
            } else{
                txtConfirmContrasenya.setTransformationMethod(null);
                valor2 = 1;
            }
        });
        //Conexion con la base de datos
        miBd = FirebaseDatabase.getInstance().getReference();

        //Al clicar en el boton Registro, se hará lo siguiente
        registro.setOnClickListener(v -> {
            copiarDatos();
            comprobarDatos();
            if (!errorPass && !errorEmail && !errorName) {
                miBd.child("Informacion").child(Nombre).child("nombre").get().addOnCompleteListener(task -> {
                    if (!task.isSuccessful()) {

                    }else{
                        if(!Nombre.equals(String.valueOf(task.getResult().getValue()))){
                            //Si luego de las comprobaciones, está bien el usuario, se envia a la base de datos
                                usuario user = new usuario(Nombre, Email, Contrasenya, distancia,
                                        puntoFin, puntoPartida, nivel, puntuacion);

                                miBd.child("Informacion").child(Nombre).setValue(user);
                            Toast.makeText(this, getString(R.string.userCreado), Toast.LENGTH_SHORT).show();
                            finish();
                            onBackPressed();

                        }else{
                            //Si el usuario ya esta registrado
                            txtnombre.setError(getString(R.string.userYaCreado));
                        }
                    }
                });
            }
        });

    }

    //Metodo para quitar espacios
    public void copiarDatos() {
        Nombre = txtnombre.getText().toString().trim();
        Nombre.replace(" ", "");

        Email = txtemail.getText().toString().trim();
        Email.replace(" ", "");

        Contrasenya = txtContrasenya.getText().toString().trim();
        Contrasenya.replace(" ", "");

        ConfirmContrasenya = txtConfirmContrasenya.getText().toString().trim();
        ConfirmContrasenya.replace(" ", "");
    }

    //Metodo para comprobar el correo
    public int comprobarEmail(String email) {

        int cont = email.indexOf("@");

        if ((cont <= 3 && cont >= 1) || cont == -1 || cont == 0) { return 0; }

            String[] separar = email.split("@");

            if(separar.length != 2){ return 0;}

            String[] dom = separar[1].split("\\.");

            if(dom.length != 2) {return 0;}

            if (dom[0].length() <= 3) { return 0; }

            if(dom[1] != null) {
                switch (dom[1]) {
                    case "es":
                        break;
                    case "com":
                        break;
                    case "org":
                        break;
                    case "gov":
                        break;
                    default:
                        return 2;
                }
            } else {
                return 0;
            }
        return 1;
    }

    //Metodo para comprobar los campos y decirle al usuario si algo anda mal
    public void comprobarDatos() {
        if (Nombre.length() >= 4) {
            errorName = false;
        } else {
            errorName = true;
            txtnombre.setError(getString(R.string.nombreIncorrecto));
        }

        switch (comprobarEmail(Email)) {
            case 1:
                errorEmail = false;
                break;
            case 2:
                errorEmail = true;
                txtemail.setError(getString(R.string.emailTipo));
                break;
            default:
                errorEmail = true;
                txtemail.setError(getString(R.string.emailIncorrecto));
                break;
        }

        if (txtConfirmContrasenya.getText().toString().equals(txtContrasenya.getText().toString())) {
            errorPass = false;
        } else {
            errorPass = true;
            txtConfirmContrasenya.setError(getString(R.string.contraseñasIncorrectas));
        }
        if (Contrasenya.length() >= 4) {
            errorPass = false;
        } else {
            errorPass = true;
            txtContrasenya.setError(getString(R.string.contraseñaIncorrecta));
        }
        if (ConfirmContrasenya.length() >= 4) {
            errorPass = false;
            if (!Contrasenya.equals(ConfirmContrasenya)) {
                txtConfirmContrasenya.setError(getString(R.string.contraseñasIncorrectas));
                errorPass = true;
            } else {
                errorPass = false;
            }
        } else {
            errorPass = true;
            txtConfirmContrasenya.setError(getString(R.string.contraseñaIncorrecta));
        }
    }

}