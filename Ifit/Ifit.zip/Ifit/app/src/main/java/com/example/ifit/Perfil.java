package com.example.ifit;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class Perfil extends AppCompatActivity {

    //Crear los diferentes objetos donde se guardaran los parámetros para la base de datos y cosas varias
    private ImageView flecha;
    private TextView txtNombre, txtNivel, txtDistancia, txtPuntos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        //Asignar todos los objetos que necesitemos con el objeto del layout
        flecha = findViewById(R.id.flecha);
        txtNombre = findViewById(R.id.txtNombre);
        txtNivel = findViewById(R.id.txtNivel);
        txtDistancia = findViewById(R.id.txtDistancia);
        txtPuntos = findViewById(R.id.txtPuntos);

        txtNombre.setText(Login.getID());

        txtNivel.setText(String.valueOf(Mapa.getNivel()));
        txtPuntos.setText(String.valueOf(Mapa.getPuntos()));
        txtDistancia.setText(String.valueOf((int) Mapa.getDistancia()));

        flecha.setOnClickListener(v -> {
            finish();
            onBackPressed();
        });
    }
}