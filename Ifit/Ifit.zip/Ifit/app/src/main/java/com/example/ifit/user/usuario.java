package com.example.ifit.user;

public class usuario {
    private String nombre, email, contrasenya, puntoFin, puntoPartida;
    private int nivel, puntuacion;
    private float distancia;

    public usuario(String nombre, String email, String contrasenya, float distancia, String puntoFin, String puntoPartida, int nivel, int puntuacion) {
        this.nombre = nombre;
        this.email = email;
        this.contrasenya = contrasenya;
        this.distancia = distancia;
        this.puntoFin = puntoFin;
        this.puntoPartida = puntoPartida;
        this.nivel = nivel;
        this.puntuacion = puntuacion;
    }

    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }

    public String getContrasenya() {
        return contrasenya;
    }
    public void setContrasenya(String contrasenya) {
        this.contrasenya = contrasenya;
    }

    public float getDistancia() {
        return distancia;
    }
    public void setDistancia(String nombre) {
        this.distancia = distancia;
    }

    public String getPuntoFin() {
        return puntoFin;
    }
    public void setPuntoFin(String nombre) {
        this.puntoFin = puntoFin;
    }

    public String getPuntoPartida() {
        return puntoPartida;
    }
    public void setPuntoPartida(String nombre) {
        this.puntoPartida = puntoPartida;
    }

    public int getNivel() {
        return nivel;
    }
    public void setNivel(String nombre) {
        this.nivel = nivel;
    }

    public int getPuntuacion() {
        return puntuacion;
    }
    public void setPuntuacion(String nombre) {
        this.puntuacion = puntuacion;
    }

    @Override
    public String toString() {
        return "usuario{" +
                "Nombre='" + nombre + '\'' +
                ", Email='" + email + '\'' +
                ", Contrasenya='" + contrasenya + '\'' +
                ", Distancia='" + distancia + '\'' +
                ", puntoFin='" + puntoFin + '\'' +
                ", puntoPartida='" + puntoPartida + '\'' +
                ", nivel='" + nivel + '\'' +
                ", puntuacion='" + puntuacion + '\'' +
                '}';
    }
}
