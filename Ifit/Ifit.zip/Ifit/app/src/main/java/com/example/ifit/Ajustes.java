package com.example.ifit;

import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ToggleButton;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

public class Ajustes extends AppCompatActivity {

    //Crear los diferentes objetos donde se guardaran los parámetros para la base de datos y cosas varias
    private ImageView flecha;
    private TextView terms, txtIdioma, txtSettings;
    private Button buttonEsp, buttonEng, buttonCat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajustes);

        //Asignar al objeto Flecha a partir de la imagen del Layout
        flecha = findViewById(R.id.flecha);

        //Asignar al objeto Terms a partir del texto del Layout
        terms = findViewById(R.id.terms);
        txtIdioma = findViewById(R.id.txtIdioma);
        txtSettings = findViewById(R.id.txtSettings);

        buttonEsp = findViewById(R.id.buttonEsp);
        buttonEng = findViewById(R.id.buttonEng);
        buttonCat = findViewById(R.id.buttonCat);

        //Al clicar en el texto "Terminos y condiciones", se redigirirá a la ventana Terminos
        terms.setOnClickListener(v -> {
            startActivity(new Intent(Ajustes.this, Terminos.class));
        });

        //Al clicar en la imagen de la flecha, se redirigirá a la ventana Mapa
        flecha.setOnClickListener(v -> {
            finish();
            onBackPressed();
        });

        buttonEsp.setOnClickListener(v -> {
            idioma("es");
            txtSettings.setText(getString(R.string.ajustes));
            txtIdioma.setText(getString(R.string.idioma));
            terms.setText(getString(R.string.terminos));
        });
        buttonEng.setOnClickListener(v -> {
            idioma("en");
            txtSettings.setText(getString(R.string.ajustes));
            txtIdioma.setText(getString(R.string.idioma));
            terms.setText(getString(R.string.terminos));
        });
        buttonCat.setOnClickListener(v -> {
            idioma("ca");
            txtSettings.setText(getString(R.string.ajustes));
            txtIdioma.setText(getString(R.string.idioma));
            terms.setText(getString(R.string.terminos));
        });

    }

    public void idioma(String localeCode) {
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            conf.setLocale(new Locale(localeCode.toLowerCase()));
        } else {
            conf.locale = new Locale(localeCode.toLowerCase());
        }
        res.updateConfiguration(conf, dm);
    }

}