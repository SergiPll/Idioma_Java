package com.example.ifit;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.os.Looper;
import android.widget.ImageView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class Mapa extends AppCompatActivity implements OnMapReadyCallback {

    //Crear los diferentes objetos donde se guardaran los parámetros para la base de datos y cosas varias
    private String distanceMoveMeters;
    private GoogleMap mGoogleMap;
    private SupportMapFragment mapFrag;
    private Marker mCurrLocationMarker;
    private float distanciaacumulada, distanciaguardada;
    private LocationRequest mLocationRequest;
    private Location mLastLocation;
    private ImageView ajustes, perfil;

    private static float distanciafirebase;

    private int puntMax;
    private static int punt, nivel = 1;
    private FusedLocationProviderClient mFusedLocationClient;

    private DatabaseReference miBd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mapa);

        //Asignar todos los objetos que necesitemos con el objeto del layout
        ajustes = findViewById(R.id.ajustes);
        perfil = findViewById(R.id.perfil);

        //Al clicar en el la rueda, se hará lo siguiente
        ajustes.setOnClickListener(v -> {
            startActivity(new Intent(Mapa.this, Ajustes.class));
        });

        //Al clicar en el la " i ", se hará lo siguiente
        perfil.setOnClickListener(v -> {
            startActivity(new Intent(Mapa.this, Perfil.class));
        });

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        mapFrag = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        mapFrag.getMapAsync(this);

        //Conexion con la base de datos
        miBd = FirebaseDatabase.getInstance().getReference();

        //Sacar el valor "distancia" de la base de datos
        miBd.child("Informacion").child(Login.getID()).child("distancia").get().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                distanciaguardada = 0;
            }
            else {
                distanciaguardada = Float.valueOf(String.valueOf(task.getResult().getValue()));
                setDistancia(distanciaguardada);
            }
        });
        //Sacar el valor "puntuacion" de la base de datos
        miBd.child("Informacion").child(Login.getID()).child("puntuacion").get().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                punt = 0;
            }
            else {
                punt = Integer.valueOf(String.valueOf(task.getResult().getValue()));
            }
        });
        //Sacar el valor "nivel" de la base de datos
        miBd.child("Informacion").child(Login.getID()).child("nivel").get().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {
                nivel = 1;
            }
            else {
                nivel = Integer.valueOf(String.valueOf(task.getResult().getValue()));
            }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mFusedLocationClient != null) {
            mFusedLocationClient.removeLocationUpdates(mLocationCallback);
        }
    }

    LocationCallback mLocationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(LocationResult locationResult) {
            List<Location> locationList = locationResult.getLocations();
            if (locationList.size() > 0) {
                // La ultima ubicacion en la lista es la mas actual
                Location location = locationList.get(locationList.size() - 1);

                if(mLastLocation!=null){

                    //Hacer los calculos de cuanta distancia lleva el usuario
                    distanciaacumulada = distanciaacumulada + location.distanceTo(mLastLocation);
                    distanciafirebase = distanciaacumulada + distanciaguardada;
                    distanceMoveMeters = String.valueOf(distanciafirebase);

                    //Calculos del Nivel y la Puntuacion
                    puntMax = nivel * 100;
                    punt = ((int) distanciafirebase / 20 * 5);
                    if (punt >= puntMax) {
                        nivel++;
                        puntMax = nivel * 100;
                    }

                    //Enviar esos 3 valores a la base de datos
                    miBd.child("Informacion").child(Login.getID()).child("distancia").setValue(distanceMoveMeters);
                    miBd.child("Informacion").child(Login.getID()).child("nivel").setValue(nivel);
                    miBd.child("Informacion").child(Login.getID()).child("puntuacion").setValue(punt);
                }
                mLastLocation = location;


                // Quitamos el marcador de posicion anterior
                if (mCurrLocationMarker != null) {
                    mCurrLocationMarker.remove();
                }

                // Ponemos marcador de posicion actual
                LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(latLng);
                markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA));
                mCurrLocationMarker = mGoogleMap.addMarker(markerOptions);
                // mGoogleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 16));
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mGoogleMap = googleMap;
        // Poner tipo de mapa: normal, terreno, satÃ©lite, hibrido...
        mGoogleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);

        // Creacion de solicitud de ubicacion
        mLocationRequest = new LocationRequest();
        // Solicitud de ubicacion cada X milisegundos
        mLocationRequest.setInterval(500);
        mLocationRequest.setFastestInterval(250);
        // Distintas opciones de precision de la ubicacion y consumo de bateria
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            //Activamos solicitudes de ubicacion
            mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper());
            mGoogleMap.setMyLocationEnabled(true);
        } else {
            //De lo contrario solicitamos permiso de ubicacion
            checkLocationPermission();
        }
    }

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        }
    }

    //Metodo para pedir al usuario que acepte los permisos de la ubicacion
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                // Si la peticion de permisos se cancela, el resultado esta vacio
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // Si el permiso se otorga, registrar solicitudes de ubicacion
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {
                        mFusedLocationClient.requestLocationUpdates(mLocationRequest, mLocationCallback, Looper.myLooper());
                        mGoogleMap.setMyLocationEnabled(true);
                    }

                } else {
                    // Permiso denegado.
                    final AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setTitle(getString(R.string.permisos)) // Titulo
                            .setMessage(getString(R.string.ubicacionCancelada))  // Mensaje
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() { // Boton para activarlo
                                public void onClick(final DialogInterface dialog, final int id) {
                                    dialog.cancel();
                                }
                            });
                    final AlertDialog alert = builder.create();
                    alert.show();
                }
                return;
            }
        }
    }

    //Metodos para pasarle a la ventana Perfil los datos sin hacer otra conexion a la base de datos
    public static void setNivel(int valor) { nivel = valor; }
    public static int getNivel() { return nivel; }

    public static void setPuntos(int valor) { punt = valor; }
    public static int getPuntos() { return punt; }

    public static void setDistancia(float valor) { distanciafirebase = valor; }
    public static float getDistancia() { return distanciafirebase; }

}