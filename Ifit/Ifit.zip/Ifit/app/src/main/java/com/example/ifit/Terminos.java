package com.example.ifit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Terminos extends AppCompatActivity {

    //Crear los diferentes objetos donde se guardaran los parámetros para la base de datos y cosas varias
    ImageView flecha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terminos);

        //Asignar al objeto Flecha a partir de la imagen del Layout
        flecha = findViewById(R.id.flecha);

        //Al clicar en la imagen de la flecha, se redirigirá a la ventana Ajustes
        flecha.setOnClickListener(v -> {
            finish();
            onBackPressed();
        });


    }

}