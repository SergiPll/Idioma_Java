package com.example.ifit;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.LocationManager;
import android.os.Bundle;
import android.provider.Settings;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Login extends AppCompatActivity {

    private DatabaseReference bd;
    private static String ID;

    //Crear los diferentes strings donde se guardaran los parámetros para la base de datos
    private Button login, registro, bttnMostrar;
    private EditText txtNombre, txtContrasenya;
    private TextView name;
    private String nombre, contrasenya;
    private int valor = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Iniciar la instancia de Firebase
        bd = FirebaseDatabase.getInstance().getReference();

        //Asignar todos los objetos que necesitemos con el objeto del layout
        login = findViewById(R.id.bttnLogin);
        registro = findViewById(R.id.bttnRegistro);
        bttnMostrar = findViewById(R.id.bttnMostrar);
        name = findViewById(R.id.name);

        txtNombre = findViewById(R.id.txtNombre);
        txtContrasenya = findViewById(R.id.txtContrasenya);

        //Asignar que la contraseña en un principio este escondida
        txtContrasenya.setTransformationMethod(new PasswordTransformationMethod());

        //Al clicar en el ojo, la contraseña cambiara entre mostrarse o esconderse
        bttnMostrar.setOnClickListener(v -> {
            if(valor == 1){
                txtContrasenya.setTransformationMethod(new PasswordTransformationMethod());
                valor = 0;
            } else{
                txtContrasenya.setTransformationMethod(null);
                valor = 1;
            }
        });

        //Al clicar en el boton Login, se hará lo siguiente
        login.setOnClickListener(v -> {
            comprobarCampos();
        });
        //Al clicar en el boton Registro, se hará lo siguiente
        registro.setOnClickListener(v -> {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.terminos)) // Titulo del cuadro de dialogo
                    .setMessage(getString(R.string.terminosMensaje))  // Mensaje
                    .setPositiveButton(getString(R.string.si), new DialogInterface.OnClickListener() {
                        public void onClick(final DialogInterface dialog, final int id) {
                            startActivity(new Intent(Login.this, Registro.class)); //Cambiar de ventana
                            dialog.cancel(); //Cerrar el mensaje
                        }
                    });
            final AlertDialog alert = builder.create();
            alert.show();
        });
    }

    //Este metodo comprueba que el usuario y la contraseña existan en la base de datos
    private void comprobarCampos() {
        nombre = txtNombre.getText().toString();
        contrasenya = txtContrasenya.getText().toString();

        bd.child("Informacion").child(nombre).child("contrasenya").get().addOnCompleteListener(task -> {
            if (!task.isSuccessful()) {

            }else {
                if(task.getResult().getValue() != null){
                    if(contrasenya.equals(String.valueOf(task.getResult().getValue()))){ //Si la contraseña coincide -->
                        locationEnabled();
                    }else{
                        // Si la contraseña no coincide -->
                        txtContrasenya.setError(getString(R.string.wrongPass));
                    }
                }else{
                    // Si el usuario no es igual a uno en la base de datos -->
                    txtNombre.setError(getString(R.string.wrongUser));
                }
            }
        });
    }

    //Metodo que se llama si existe el usuario y contraseña correcta
    private void locationEnabled () {
        LocationManager lm = (LocationManager)
                getSystemService(Context. LOCATION_SERVICE ) ;
        boolean gps_enabled = false;
        boolean network_enabled = false;
        try {
            gps_enabled = lm.isProviderEnabled(LocationManager. GPS_PROVIDER ) ;
        } catch (Exception e) {
            e.printStackTrace() ;
        }
        try {
            network_enabled = lm.isProviderEnabled(LocationManager. NETWORK_PROVIDER ) ;
        } catch (Exception e) {
            e.printStackTrace() ;
        }
        //Si no está la ubicacion activada -->
        if (!gps_enabled && !network_enabled) {
            final AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.ubicacionPermisos)) // Titulo del cuadro de dialogo
                    .setMessage(getString(R.string.ubicacion))  // Mensaje
                    .setPositiveButton(getString(R.string.ubicacionSi), new DialogInterface.OnClickListener() { // Activar
                        public void onClick(final DialogInterface dialog, final int id) {
                            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); //Abrir la ubicacion
                        }
                    });
            final AlertDialog alert = builder.create();
            alert.show();
        } else {
            setID(nombre);
            startActivity(new Intent(Login.this, Mapa.class));
            finish();
        }
    }

    //Estos metodos los usare en otras ventanas para pasarles que usuario esta logueado, para no
    //pedir la conexion otra vez a la base de datos
    public static void setID(String id) { ID = id; }
    public static String getID() { return ID; }

    //El metodo que sirve como darle hacia atras en el movil, esta puesto para que cierre la ventana
    @Override
    public void onBackPressed() {
        finish();
    }
}